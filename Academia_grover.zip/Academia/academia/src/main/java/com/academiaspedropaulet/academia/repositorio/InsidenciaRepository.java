package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Insidencia;

public interface InsidenciaRepository extends ICrudGenericoRepository<Insidencia, Long> {
}
