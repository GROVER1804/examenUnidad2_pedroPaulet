package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Cargo;


public interface CargoRepository extends ICrudGenericoRepository<Cargo, Long>{
}
