export class Trabajador{
  idTrabajador: number
  nombre: String
  apellido: String
  contrasena: String
  cargo: String
}
