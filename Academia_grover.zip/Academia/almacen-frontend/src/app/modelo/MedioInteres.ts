export class MedioInteres {
  idMedioInteres: number;
  nombreMedio: string;
}
