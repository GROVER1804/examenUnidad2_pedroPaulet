export class Estudiante {
    idEstudiante: number
    nombreCompleto: string
    apellidoPaterno: string
    apellidoMaterno: string
    dni: string
    medioInteres: string
}
