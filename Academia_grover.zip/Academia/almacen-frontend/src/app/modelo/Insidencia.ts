export class Insidencia{
  idInsidencia: number
  descripcion: string
  castigo: string
  estudiante: string
}
